package fr.fekra.qa.selenium.actions.sf;


import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import fr.fekra.qa.selenium.tnr.action.TstFmwkAction;
import fr.fekra.qa.selenium.tnr.action.selenium.AbstractSeleniumAction;
import fr.fekra.qa.selenium.tnr.analyse.Context;
import fr.fekra.qa.selenium.tnr.analyse.ctx.ActionStep;

@Component
public class SalefsorceSubmitApprovalAction extends AbstractSeleniumAction
    implements TstFmwkAction {

  @Qualifier("ProceniumLogger")
  @Autowired
  private Logger LOGGER;
  private static int WAIT_SALESFORCE_TIME = 5000;

  @Override
  public String getKey() {
    return "salesforce-submit-approval";
  }

  @Override
  public boolean executeAction(ActionStep step, Context context) throws Exception {
    LOGGER.info("Submit Approval");

    getActiveElement().sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.ENTER,
        Keys.ENTER);
    sleep(1000);
    typeOnActiveElement(context.getScenario().getProperty(step.getActionKey() + ".comment.value"));
    sleep(1000);
    getActiveElement().sendKeys(Keys.TAB, Keys.TAB, Keys.ENTER);

    sleep(WAIT_SALESFORCE_TIME);

    return true;
  }

}
