package fr.fekra.qa.selenium.actions.sf;

import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import fr.fekra.qa.selenium.tnr.action.TstFmwkAction;
import fr.fekra.qa.selenium.tnr.action.selenium.AbstractSeleniumAction;
import fr.fekra.qa.selenium.tnr.analyse.Context;
import fr.fekra.qa.selenium.tnr.analyse.ctx.ActionStep;

@Component
public class SalefsorceNewPartnerAction extends AbstractSeleniumAction implements TstFmwkAction {

  @Qualifier("ProceniumLogger")
  @Autowired
  private Logger LOGGER;
  private static int WAIT_SALESFORCE_TIME = 5000;

  @Override
  public String getKey() {
    return "salesforce-new-partner";
  }

  @Override
  public boolean executeAction(ActionStep step, Context context) throws Exception {
    LOGGER.info("New Partner");

    // get xpath
    Map<String, String> xpathMap = resolveXpath(context, step);

    click("click on New partnership  ",
        By.xpath(xpathMap.get("newPartnership.xpath").replace("New PartnerShip",
            context.getScenario().getProperty(step.getActionKey() + ".newPartnership.button"))));

    sleep(3000);
    getActiveElement().sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,
        Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.ENTER);
    selectElementFromLigtningCombobox(1);
    sleep(1000);
    getActiveElement().sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.ENTER);
    selectElementFromLigtningCombobox(1);
    sleep(1000);
    click("click on save ", By.xpath(xpathMap.get("savePartnership.xpath")));
    sleep(WAIT_SALESFORCE_TIME);
    return true;
  }

}
