package fr.fekra.qa.selenium.actions.sf;


import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import fr.fekra.qa.selenium.tnr.action.TstFmwkAction;
import fr.fekra.qa.selenium.tnr.action.selenium.AbstractSeleniumAction;
import fr.fekra.qa.selenium.tnr.analyse.Context;
import fr.fekra.qa.selenium.tnr.analyse.ctx.ActionStep;

@Component
public class SalesforceGoToApprovalAction extends AbstractSeleniumAction implements TstFmwkAction {

  @Qualifier("ProceniumLogger")
  @Autowired
  private Logger LOGGER;

  @Override
  public String getKey() {
    return "salesforce-go-to-approval";
  }

  @Override
  public boolean executeAction(ActionStep step, Context context) throws Exception {

    LOGGER.info("Go to Account screen");

    // get xpath
    Map<String, String> xpathMap = resolveXpath(context, step);

    type("type id .. ", By.xpath(xpathMap.get("search.xpath")), context.getScenario().getProperty(
        context.getScenario().getProperty(step.getActionKey() + ".approval.id.value")));

    getActiveElement().sendKeys(Keys.ENTER);
    sleep(1000);
    getActiveElement().sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,
        Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.ENTER, Keys.ENTER);
    sleep(5000);
    return true;
  }

}
