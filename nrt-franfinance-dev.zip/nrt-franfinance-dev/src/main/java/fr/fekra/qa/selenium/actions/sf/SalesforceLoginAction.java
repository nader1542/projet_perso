/*
 *
 */

package fr.fekra.qa.selenium.actions.sf;



import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import fr.fekra.qa.selenium.tnr.action.TstFmwkAction;
import fr.fekra.qa.selenium.tnr.action.selenium.AbstractSeleniumAction;
import fr.fekra.qa.selenium.tnr.analyse.Context;
import fr.fekra.qa.selenium.tnr.analyse.ctx.ActionStep;

@Component
public class SalesforceLoginAction extends AbstractSeleniumAction implements TstFmwkAction {

  @Qualifier("ProceniumLogger")
  @Autowired
  private Logger LOGGER;


  @Override
  public String getKey() {
    return "salesforce-login";
  }

  @Override
  public boolean executeAction(ActionStep step, Context context) throws Exception {
    LOGGER.info("Login");


    type("User ", By.id("username"), context.getScenario().getProperty("common.user"));
    type("Password ", By.id("password"), context.getScenario().getProperty("common.password"));
    click("Login button", By.id("Login"));
    sleep(5000);

    return true;
  }

}
