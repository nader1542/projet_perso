package fr.fekra.qa.selenium.actions.sf;

import java.util.Map;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import fr.fekra.qa.selenium.tnr.action.TstFmwkAction;
import fr.fekra.qa.selenium.tnr.action.selenium.AbstractSeleniumAction;
import fr.fekra.qa.selenium.tnr.analyse.Context;
import fr.fekra.qa.selenium.tnr.analyse.ctx.ActionStep;

@Component
public class SalesforceGoToAccountsAction extends AbstractSeleniumAction implements TstFmwkAction {

  @Qualifier("ProceniumLogger")
  @Autowired
  private Logger LOGGER;

  @Override
  public String getKey() {
    return "salesforce-go-to-accounts";
  }

  @Override
  public boolean executeAction(ActionStep step, Context context) throws Exception {

    LOGGER.info("Go to Accounts screen");

    // get xpath
    Map<String, String> xpathMap = resolveXpath(context, step);



    click(" on menu button ", By.xpath(xpathMap.get("globalMenu.xpath")));
    click(" on view all  ", By.xpath(xpathMap.get("viewAll.xpath")));
    sleep(1000);
    context.getWebDriver().switchTo().activeElement()
        .sendKeys(context.getScenario().getProperty(step.getActionKey() + ".accounts.label"));
    sleep(1000);
    click(" on accounts menu ", By.xpath(xpathMap.get("account.xpath")));

    return true;
  }

}
