/*
 *
 */

package fr.fekra.qa.selenium.actions.sf;

import java.util.Map;
import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import fr.fekra.qa.selenium.tnr.action.TstFmwkAction;
import fr.fekra.qa.selenium.tnr.action.selenium.AbstractSeleniumAction;
import fr.fekra.qa.selenium.tnr.analyse.Context;
import fr.fekra.qa.selenium.tnr.analyse.ctx.ActionStep;

@Component
public class SalesforceLogoutAction extends AbstractSeleniumAction implements TstFmwkAction {


  @Qualifier("ProceniumLogger")
  @Autowired
  private Logger LOGGER;


  @Override
  public String getKey() {
    return "salesforce-logout";
  }

  @Override
  public boolean executeAction(ActionStep step, Context context) throws Exception {
    LOGGER.info("Logout");

    // get xpath
    Map<String, String> xpathMap = resolveXpath(context, step);



    click(" Profile zone ", By.xpath(xpathMap.get("profilezone.xpath")));
    click(" Logout button ",
        By.linkText(context.getScenario().getProperty(step.getActionKey() + ".logout.label")));
    sleep(5000);
    return true;
  }

}
