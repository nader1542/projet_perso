package fr.fekra.qa.selenium.actions.sf;

import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import fr.fekra.qa.selenium.tnr.action.TstFmwkAction;
import fr.fekra.qa.selenium.tnr.action.selenium.AbstractSeleniumAction;
import fr.fekra.qa.selenium.tnr.analyse.Context;
import fr.fekra.qa.selenium.tnr.analyse.ctx.ActionStep;

@Component
public class SalefsorceNewApprovalAction extends AbstractSeleniumAction implements TstFmwkAction {


  @Qualifier("ProceniumLogger")
  @Autowired
  private Logger LOGGER;
  private static int WAIT_SALESFORCE_TIME = 5000;

  @Override
  public String getKey() {
    return "salesforce-new-approval";
  }

  @Override
  public boolean executeAction(ActionStep step, Context context) throws Exception {
    LOGGER.info("New Approval");

    // get xpath
    Map<String, String> xpathMap = resolveXpath(context, step);

    getActiveElement().sendKeys(Keys.PAGE_UP);
    sleep(2000);

    click("click on button New ", By.xpath(xpathMap.get("new.xpath").replace("New",
        context.getScenario().getProperty(step.getActionKey() + ".new.button"))));

    sleep(7000);

    selectElementFromLigtningRadiolist(Integer.valueOf(
        context.getScenario().getProperty(step.getActionKey() + ".selectedApprovalType.order")));

    click("click on button Next ", By.xpath(xpathMap.get("next.xpath").replace("Next",
        context.getScenario().getProperty(step.getActionKey() + ".next.button"))));
    sleep(WAIT_SALESFORCE_TIME);

    getActiveElement().sendKeys(Keys.ARROW_DOWN);
    sleep(WAIT_SALESFORCE_TIME);
    selectElementFromLigtningCombobox(Integer.valueOf(
        context.getScenario().getProperty(step.getActionKey() + ".selectedPartner.order")));

    // go to Date approbation
    selectFieldFromLigtningForm(Integer.valueOf(
        context.getScenario().getProperty(step.getActionKey() + ".date.approbation.form.order")));

    typeOnActiveElement(
        context.getScenario().getProperty(step.getActionKey() + ".date.approbation.value"));

    // Type de demande
    selectFieldFromLigtningForm(Integer.valueOf(
        context.getScenario().getProperty(step.getActionKey() + ".demandType.form.order")));
    selectElementFromLigtningCombobox(Integer
        .valueOf(context.getScenario().getProperty(step.getActionKey() + ".demandType.order")));

    // Type agréement
    selectFieldFromLigtningForm(Integer.valueOf(
        context.getScenario().getProperty(step.getActionKey() + ".approvalType.form.order")));
    selectElementFromLigtningCombobox(Integer
        .valueOf(context.getScenario().getProperty(step.getActionKey() + ".approvalType.order")));

    // Responsable commerciale
    selectFieldFromLigtningForm(Integer.valueOf(context.getScenario()
        .getProperty(step.getActionKey() + ".selectedSalesResponsable.form.order")));
    typeOnActiveElement(
        context.getScenario().getProperty(step.getActionKey() + ".selectedSalesResponsable.value"));
    selectElementFromLigtningCombobox(Integer.valueOf(context.getScenario()
        .getProperty(step.getActionKey() + ".selectedSalesResponsable.order")));

    // Directeur approbateur
    selectFieldFromLigtningForm(Integer.valueOf(
        context.getScenario().getProperty(step.getActionKey() + ".lastSubmitter.form.order")));
    selectElementFromLigtningCombobox(Integer
        .valueOf(context.getScenario().getProperty(step.getActionKey() + ".lastSubmitter.order")));
    sleep(2000);
    click("click on adm checkbox", By.xpath(xpathMap.get("adm.xpath").replace("Adm",
        context.getScenario().getProperty(step.getActionKey() + ".adm.value"))));
    sleep(2000);
    click("click on save ", By.xpath(xpathMap.get("save.xpath").replace("Save",
        context.getScenario().getProperty(step.getActionKey() + ".save.button"))));

    sleep(WAIT_SALESFORCE_TIME);



    return true;
  }

}
