/*
 *
 */

package fr.fekra.qa.selenium;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import fr.fekra.qa.selenium.tnr.AbstractStarter;

@SpringBootApplication
@ComponentScan("fr.fekra.qa.selenium")
public class TnrStarter extends AbstractStarter {
    public static void main(String[] args) {
        execute(TnrStarter.class, args);
    }
}
