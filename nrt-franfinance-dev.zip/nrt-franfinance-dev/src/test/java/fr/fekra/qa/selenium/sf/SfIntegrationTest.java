/*
 *
 */

package fr.fekra.qa.selenium.sf;

import java.io.File;
import java.util.Arrays;

import fr.fekra.qa.selenium.AbstractRunSelenium;


public class SfIntegrationTest extends AbstractRunSelenium {

    public static final File CASES_DIR = new File("cases-sf");

  //  @Parameters(name = "{0}")
    public static Iterable<? extends Object> data() {
        String[] tests = CASES_DIR.list((dir, name) -> {
            return dir.equals(CASES_DIR) && name.endsWith(".md");
        });
        return Arrays.asList(tests);
    }

    @Override
    public File getCasesDir() {
        return CASES_DIR;
    }

}
