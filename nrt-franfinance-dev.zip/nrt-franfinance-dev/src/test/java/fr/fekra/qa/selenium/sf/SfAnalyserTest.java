/*
 *
 */

package fr.fekra.qa.selenium.sf;

import static org.junit.Assert.*;

import fr.fekra.qa.selenium.TnrStarter;
import java.io.File;
import org.junit.Test;

public class SfAnalyserTest {

//    @Test
    public void analyseConnection() {
        analyse("Create_new_Partner");
    }

    private void analyse(String scenario) {
        try {
            File scenarioFile = new File(SfIntegrationTest.CASES_DIR, scenario + ".md");

            TnrStarter.main(new String[] { "--cmd=analyse" //
                    , "--scenario=" + scenarioFile.getAbsolutePath() //
                    , "--env=dev-local" //
                    , "--out=target/analyse-" + scenario//
            });
        } catch (Exception e) {
            fail("Unexpected Exception");
        }
    }

}
