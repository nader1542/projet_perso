/*
 *
 */

package fr.fekra.qa.selenium;

import static org.junit.Assert.fail;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runners.Parameterized.Parameter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractRunSelenium {
  private static final Logger LOGGER = LoggerFactory.getLogger(AbstractRunSelenium.class);

  public abstract File getCasesDir();

  @Parameter
  public String testName;

  public static String ENV = "";
  public static String PROFILE = "";
  public static String LANGUAGECODE = "";

  @Test
  public void runScenario() {
    try {
      TnrStarter.main(new String[] {"--cmd=execute" //
          , "--scenario=" + new File(getCasesDir(), this.testName).getAbsolutePath() //
          , "--languageCode=" + LANGUAGECODE //
          , "--profile=" + PROFILE //
          , "--out=target/RunSeleniumTest" //
      });
    } catch (Exception e) {
      LOGGER.error(e.getLocalizedMessage(), e);
      fail(e.getLocalizedMessage());
    }
  }

  @BeforeClass
  public static void configSystemProperties() {
    File propertiesFile = new File("src/test/resources/.project.properties");
    if (!propertiesFile.exists()) {
      LOGGER.error(propertiesFile.getAbsolutePath() + " does not exist");
      throw new RuntimeException(propertiesFile.getAbsolutePath() + " does not exist");
    }
    try (InputStream input = new FileInputStream(propertiesFile);) {
      Properties projectProperties = new Properties();
      projectProperties.load(input);
      String chromedriver = projectProperties.getProperty("selenium.chromedriver", "");
      if (chromedriver.length() > 0 && !chromedriver.contains("${user.selenium.chromedriver}")) {
        File chromedriverExe = new File(chromedriver);
        if (!chromedriverExe.exists()) {
          throw new IllegalArgumentException(
              "Property selenium.chromedriver is not valid: " + chromedriverExe.getAbsolutePath());
        }
        System.setProperty("webdriver.chrome.driver", chromedriverExe.getAbsolutePath());
      }
      PROFILE = projectProperties.getProperty("test.env");
    } catch (Exception e) {
      LOGGER.error(e.getLocalizedMessage(), e);
      fail("Unexpected Exception");
    }
  }

}
