
package fr.fekra.qa.selenium.sf;

public class SfRunATestManually {

  public static void main(String[] args) {
    SfRunATestManually tst = new SfRunATestManually();
    tst.execute("Test_Connection.md", "FR", "local");

  }

  private void execute(String testName, String languageCode, String profile) {
    SfIntegrationTest test = new SfIntegrationTest();
    SfIntegrationTest.configSystemProperties();


    SfIntegrationTest.LANGUAGECODE = languageCode;
    SfIntegrationTest.PROFILE = profile;


    test.testName = testName;
    test.runScenario();
  }

}
