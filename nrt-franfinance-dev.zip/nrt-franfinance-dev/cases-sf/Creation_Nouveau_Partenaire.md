# Creation d'un nouveau partenariat

L'objectif de ce scénario est de créer un nouveau partenaire

Ce scénario utilise le fichier de configuration  {config:sf._PROFILE_.properties}




La liste des process est :

1. L'utilisateur se connecte à l'application {process:Connexion}

2. Il crée un nouveau compte  {process:Creation-Compte}

3. Il crée un nouveau partenariat avec ce partenaire {process:Creation-Partenariat}

4. A la fin, l'utilisateur se déconnecte {process:Deconnexion}

