# Création d'un nouveau agrément 

L'objectif de ce scénario est de créer un nouveau partenaire, lui créer un agrément et envoyer l'agrément pour validation

Le teste utilise le fichier de configuration {config:sf._PROFILE_.properties}




Le workflow est le suivant :


1. L'utilisateur se connecte à l'application {process:Connexion}

2. Il crée un nouveau compte  {process:Creation-Compte}

3. Il crée un nouveau partenariat avec ce partenaire {process:Creation-Partenariat}

4. Il crée un agrément pour ce partenaire {process:Creation-Agrement}

5. Il envoie l'agrément pour validation {process:Validation-Agrement}

6. A la fin, l'utilisateur se déconnecte {process:Deconnexion}







