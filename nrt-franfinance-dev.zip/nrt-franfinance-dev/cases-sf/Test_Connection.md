# Teste connection

L'objectif de ce scenario est de tester la disponibilite de l'application

Le teste utilise le fichier de configuration {config:sf._PROFILE_.properties}




Le workflow est le suivant :


1. L'utilisateur se connecte à l'application {process:Connexion}

2. A la fin, l'utilisateur se deconnecte {process:Deconnexion}
