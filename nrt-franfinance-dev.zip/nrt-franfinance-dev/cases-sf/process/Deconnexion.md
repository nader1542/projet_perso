# Process : Déconnexion

## Context


Ces variables doivent ètre rensignés

- browser {check:browser}
- connection url {check:common.root.url}
- welcome page url {check:common.menu.url}

## Pre-conditions


L'utilisateur est connecté à l'application {partialLocation:_common.login.url_}

## Actions

1. L'utilisateur se déconnecte {action:salesforce-logout}
2. il prend un imprime-écran {screenshot}

## Expected results

L'utilisateur est sur la page de connexion de l'application {location:_common.logout.url_}