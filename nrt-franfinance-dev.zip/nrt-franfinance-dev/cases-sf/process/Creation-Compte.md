# Process : Creation d'un nouveau compte

## Context

Ces variables doivent ètre renseignés

- partner value {check:salesforce-new-account.partner.value}
- selectedPartner order into the list of partners {check:salesforce-new-account.selectedPartner.order}
- Partner type order {check:salesforce-new-account.partnertype.value.order}
- Partnership type order {check:salesforce-new-account.partnerShiptype.value.order}
- accounts url {check:common.accounts.menu.url}
- account label {check:salesforce-go-to-accounts.accounts.label}



## Pre-conditions

L'utilisateur est dèja connecté à l'application {location:_common.menu.url_}


## Actions

1. L'utilisateur navigue au menu comptes {action:salesforce-go-to-accounts}</br>
2. Il prend un imprime-écran {screenshot}</br>
3. Il crée un nouveau compte  {action:salesforce-new-account}</br>
4. Il prend un imprime-écran {screenshot}</br>

## Expected results

L'utilisateur est dans l'écran de compte crée {partialLocation:_common.account.postAccountCreation.url_}