# Process : Connexion 

## Context

Ces variables doivent ètre rensignés

- browser {check:browser}
- connection url {check:common.root.url}
- welcome page url {check:common.menu.url}
- user {check:common.user}
- password {check:common.password:encrypt}

## Pre-conditions

n/a

## Actions

1.L'utilisateur lance le navigateur {action:OpenBrowser}</br>
2.Il se connecte à l'application {action:salesforce-login}</br>
3.Il prend un imprime-écran {screenshot}</br>

## Expected results

L'utilisateur est connecté à l'application {location:_common.menu.url_}