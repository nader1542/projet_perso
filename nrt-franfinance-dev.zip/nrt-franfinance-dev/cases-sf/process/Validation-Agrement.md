# Process : validation agrément

## Context

L'utilisateur est dèja connecté sur l'agrément à valider


## Pre-conditions

L'utilisateur est connecté sur {partialLocation:_common.approvals.postApprovalCreation.url_}


## Actions

1.L'utilisateur envoie une demande de validation de l'agrément {action:salesforce-submit-approval}</br>
2.Il prend un imprime-écran {screenshot}</br>

## Expected results

L'utilisateur est connecté sur {partialLocation:_common.approvals.postApprovalCreation.url_}