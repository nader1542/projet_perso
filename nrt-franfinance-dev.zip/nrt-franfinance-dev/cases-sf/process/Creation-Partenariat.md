# Process : Creation partenariat

## Context

Ce process permet de créer un partenariat sur un compte

## Pre-conditions

L'utilisateur est dèja connecté à la compte en question {partialLocation:_common.account.postAccountCreation.url_}


## Actions

1.L'utilisateur crée un nouveau partenariat {action:salesforce-new-partner}</br>
2.il prend un imprime-écran {screenshot}</br>

## Expected results

L'utilisateur est dans l'écran de compte en question {partialLocation:_common.account.postPartnerCreation.url_}