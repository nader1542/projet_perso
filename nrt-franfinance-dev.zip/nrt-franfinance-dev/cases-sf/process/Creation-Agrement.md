# Process : Création agrément

## Context

Ces variables doivent ètre renseignés

- approvals url {check:common.approvals.menu.url}
- approvals label {check:salesforce-go-to-approvals.approvals.label}
- approbation date value {check:salesforce-new-approval.date.approbation.value}
- Adm checkbox label  {check:salesforce-new-approval.adm.value}


## Pre-conditions




## Actions

1.L'utilisateur navigue au menu agréments {action:salesforce-go-to-approvals}</br>
2.Il prend un imprime-écran {screenshot}</br>
3.Il crée un nouveau agrément {action:salesforce-new-approval}</br>
4.Il prend un imprime-écran {screenshot}</br>

## Expected results

L'utilisateur est connecté à l'url  {partialLocation:_common.approvals.postApprovalCreation.url_}